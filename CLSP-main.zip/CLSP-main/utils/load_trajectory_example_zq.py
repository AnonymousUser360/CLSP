import os
import sys
current_file_path = os.path.abspath(__file__)

# 获取当前文件所在的目录
current_dir = os.path.dirname(current_file_path)

# 将这个目录添加到sys.path中，如果它还不在sys.path中的话
if current_dir not in sys.path:
    sys.path.append(current_dir)

from utils.config_helper import read_config
from utils.model.model import Model, Model_Plus,MultiMLPJupiter,Model_expand
from utils.features import Features
from utils.collate_fn import default_collate_with_dim
from utils.heatmap_utils.heatmap_helper import MoreMap, load_heatmap,HeatMap,load_more_map
from utils.env_info.supply_item_info import all_supply_items
import torch
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import tqdm
import numpy as np
import os
import time
import random
import json
import torch.nn as nn
from collate_fn import default_collate_with_dim

class Trajectory(nn.Module):
    def __init__(self,root_path,config_path, gpu_id=None,for_llm=True) -> None:   
        super().__init__()
        self.for_llm=for_llm
        if for_llm:
            self.ModelClass = Model_expand
            # self.ModelClass = Model_Plus
        else:
            self.ModelClass = Model         
        self.supply_item_info = all_supply_items
        self.mapsize = [403300,403300,33000]
        self.whole_cfg = read_config(config_path)
        self.heatmap_data = load_heatmap(os.path.join(root_path, self.whole_cfg.env.heat_map.heat_map_path))
        # more_map_param = load_more_map()
        # self.more_map_class = MoreMap(more_map_param,self.whole_cfg)
        self.features = Features(self.whole_cfg, heat_map_data = self.heatmap_data )
        self.model = self.ModelClass(self.whole_cfg)
        
    
    def load_model(self,root_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/llava/model/rlmodal_encoder/load_state'):
        ckpts = torch.load(os.path.join(root_path,self.whole_cfg.var2), map_location=torch.device('cpu'))
        self.model.load_state_dict(ckpts['model'])
    


 
    def preprocess_obs(self,state,objs,depth_map,last_state,last_action,info,search_target_player_id):        
        obs = self.features.transform_obs(state=state, objs=objs,last_state=last_state, last_action=last_action, info=info, depth_map=depth_map, search_target_player_id = search_target_player_id)
        obs = default_collate_with_dim([obs], )
 
        return obs
    
    def distance_via_id(self, id_1, id_2,info=None):
        if(info is None):
            info=self.info
        x1 = info['player_state'][id_1].state.position.x
        y1 = info['player_state'][id_1].state.position.y
        z1 = info['player_state'][id_1].state.position.z
        x2 = info['player_state'][id_2].state.position.x
        y2 = info['player_state'][id_2].state.position.y
        z2 = info['player_state'][id_2].state.position.z
        return np.sqrt((x1-x2)**2 + (y1-y2)**2 + (z1-z2)**2)
    
    def find_search_target(self, info, self_id ):
        info_state = info['player_state']
        distance_list = []
        id_list = []
        for id,player_state in info_state.items():
            if id!=self_id and  player_state.state.team_id != info_state[int(self_id)].state.team_id and player_state.state.alive_state!=2:   ### find nearest enemy
                distance2enemy = self.distance_via_id(self_id, id,info)
                id_list.append(id)
                distance_list.append(distance2enemy)
        if  len(distance_list)==0:
            return None
        # if min(distance_list) <= 10000: # 近距离也暴露
        #     return None
        nearest_index = distance_list.index(min(distance_list))
        nearest_id = id_list[nearest_index]
        return nearest_id
    
    def load_trajectory_onestep(self, trajectory_path=None, json_data=None,root_json_data=None): 
        # extends=json_data["Actions Extend Nums"]   
        trajectory = torch.load(trajectory_path)
        # if len(extends)==2:
        #     start_idx = max(extends[0],0)
        #     end_idx = min(len(trajectory)-extends[-1], len(trajectory))
        #     trajectory=trajectory[start_idx:end_idx]
 
        # random_idxs = list(range(len(trajectory)))
        # random.shuffle(random_idxs)
        # for i in random_idxs[:1]:
        # traj = trajectory[i]

        if isinstance(trajectory,dict):
            traj = trajectory
        elif isinstance(trajectory,list):
            self.src_action = trajectory[1]
            traj = trajectory[0]

        self.state = traj['state']
        self.objs = traj['objs']
        depth_map = traj['depth_map']
        last_state = traj['last_state']
        self.last_action = traj['last_action']
        self.info = traj['info']
        if 'enemy_id_queue' in traj.keys():
            self.features.enemy_id_queue = traj['enemy_id_queue']
        if 'enemy_info_queue' in traj.keys():
            self.features.enemy_info_queue = traj['enemy_info_queue']
        if 'ENEMY_SEE_INFO' in traj.keys():
            self.features.ENEMY_SEE_INFO = traj['ENEMY_SEE_INFO']
        if 'self_history_positions' in traj.keys():
            self.features.self_history_positions = traj['self_history_positions']
        if 'history_event_info' in traj.keys():
            self.features.history_event_info = traj['history_event_info']

        if 'search_target_player_id' in traj.keys():
            self.search_target_player_id = traj['search_target_player_id']
        else:
            self.search_target_player_id = self.find_search_target(self.info,self.features.id)
        model_input = self.preprocess_obs(state= self.state,
                                        objs= self.objs,
                                        depth_map= depth_map,
                                        last_state= last_state,
                                        last_action= self.last_action,
                                        info=self.info,
                                        search_target_player_id=self.search_target_player_id)
 
        return model_input
        
    def get_backbone_embedding_onestep(self, model_input ):
        model_output = self.model.get_backbone_embedding(model_input)
        # embed = model_output['embedding'].cpu().data.numpy()
        embed = model_output['embedding']
        return embed  
    

    def forward(self, model_input):
        embedding, only_v_embedding,heatmap_out_info,visible_enemy_embedding_no_maxpool,visible_enemy_num,visible_enemy_distance = self.model.encoder(model_input)
        if self.for_llm:
            embedding = self.model.backboneT(embedding)
            # embedding = self.model.backbone(embedding)
        else:
            embedding = self.model.backbone(embedding)
        return embedding
    
    def batch_cat(self, list_dict):
        if type(list_dict) is list:
            device=list(list_dict[0].values())[0].device
        else:
            return list_dict
        if len(list_dict)>0:
            model_input=default_collate_with_dim(list_dict,device=device,cat=True)
        else:
            model_input=[]
        return model_input
    
    # def convert_tensors_to_dtype(self,obj,dtype):
    #     if isinstance(obj, list):
    #         for i,value in enumerate(obj):
    #             self.convert_tensors_to_dtype(obj[i],dtype)
    #     if isinstance(obj, dict):
    #         # 如果是字典，递归处理字典的每个值
    #         for key, value in obj.items():
    #             self.convert_tensors_to_dtype(obj[key],dtype)
    #     elif isinstance(obj, torch.Tensor):
    #         # 如果是张量，转换类型
    #         return obj.to(device="cuda", dtype=dtype)
    #     return obj
    
    def convert_tensors_to_dtype(self,obj,dtype,device):
        if isinstance(obj, list):
            for i,value in enumerate(obj):
                obj[i] = self.convert_tensors_to_dtype(value,dtype,device)
        if isinstance(obj, dict):
            # 如果是字典，递归处理字典的每个值
            for key, value in obj.items():
                obj[key] = self.convert_tensors_to_dtype(value,dtype,device)
        elif isinstance(obj, torch.Tensor):
            # 如果是张量，转换类型
            return obj.to(device=device, dtype=dtype)
        return obj


def load_json(file_path):
    with open(file_path, 'r') as file:
        json_data = json.load(file)
    return json_data
 

def get_traj_embedding(config_path=None):
    traj_agent = Trajectory(root_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/llava/model/rlmodal_encoder/load_state',config_path=config_path)
    # root_clips_path = '/mnt/nfs2/aaa/FPS/Label_3player'
    # clip_replay_names = os.listdir(root_clips_path)
 
    # for idx,replay in enumerate(clip_replay_names):
 
    #     print(f"正在处理第{idx}个视频{replay}的clip...")
    #     clip_path = os.path.join(root_clips_path, replay)
    #     root_clip_files = os.listdir(clip_path)
    #     # root_json_path = os.path.join(clip_path, 'bak',f"{replay}.json")
    #     if 'Clip_0' in root_clip_files:
    #         clip0_path = os.path.join(root_clips_path, replay, 'Clip_0')
    #         clip0_files = os.listdir(clip0_path)
    #         for clip in clip0_files:
    #             if '.pt' in clip:
                    
    #                 # json_path = os.path.join(clip0_path, f'info_0.json')
    #                 # json_data = load_json(json_path)  
    #                 # root_json_data = load_json(root_json_path)  
    #                 traj_path = os.path.join(clip0_path, clip)
                    
                    
    #                 # model_input = traj_agent.load_trajectory_onestep(traj_path,json_data, root_json_data )
    #test
    traj_agent.load_model(root_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/llava/model/rlmodal_encoder/load_state')
    print('1')
    traj_agent.to(dtype=torch.bfloat16, device='cuda')
    for p in traj_agent.parameters():
                p.requires_grad = True
    print('2')
    # traj_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/data/DI-dataset/fps_data/Data_perstep_3p/2024-3-2-14-19-38/Clip_0/0.pt:6001'
    traj_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/data/DI-dataset/fps_data/4P_Align_Part1/desktop-server2-2024-03-19-20-01-00/Clip_0/0.pt:6002'
    traj_agent.features.id= int(traj_path.split(':')[-1])
    traj_path=traj_path.split(':')[0]
    model_input = traj_agent.load_trajectory_onestep(traj_path)
    model_input=traj_agent.convert_tensors_to_dtype(model_input,torch.bfloat16)
    model_input=[model_input,model_input]
    model_input=traj_agent.batch_cat(model_input)

    embedding  = traj_agent.forward(model_input)
    print(f"embedding size:{embedding.size()}")
    embedding=embedding.float().cpu()
    print(f"embedding:{embedding}")
    print(f"embedding size:{len(embedding[0])}")
    print(f"embedding size:{embedding.size()}")

    exit()

    #
    traj_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/data/DI-dataset/fps_data/Data_perstep_3p/2024-3-2-14-19-38/Clip_0/0.pt:6001'
    traj_agent.features.id= int(traj_path.split(':')[-1])
    traj_path=traj_path.split(':')[0]
    model_input = traj_agent.load_trajectory_onestep(traj_path)
    embedding  = traj_agent.get_backbone_embedding_onestep(model_input)
    print(f"embedding:{embedding}")
    print(f"embedding size:{len(embedding[0])}")

if __name__=='__main__':
    get_traj_embedding(config_path='/home/ccc1/nfs/ccc/ccc_nfs/MMD-project/llava/model/rlmodal_encoder/load_state/utils/user_config_replay.yaml')
